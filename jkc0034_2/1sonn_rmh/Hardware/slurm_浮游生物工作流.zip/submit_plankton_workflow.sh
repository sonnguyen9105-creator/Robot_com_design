
#!/bin/bash
#SBATCH --job-name=PlanktonAI_Workflow
#SBATCH --partition=ceoas-gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=32
#SBATCH --mem=512G
#SBATCH --gres=gpu:gh200:1
#SBATCH --time=48:00:00
#SBATCH --output=/storage/ceoas-scratch/logs/%x_%j.out
#SBATCH --error=/storage/ceoas-scratch/logs/%x_%j.err

# ==========================================

# 俄勒冈州立大学海洋科研AI集群 - 浮游生物AI识别工作流 Slurm 模板

# 适配场景：YOLOv8模型训练 / 大规模影像批量推理

# 集群环境：Rocky Linux 9.6, Slurm, NVIDIA H200/GH200

# ==========================================

# 1. 环境变量配置

export WORK_DIR="/storage/ceoas-scratch/plankton_project"
export DATA_DIR="${WORK_DIR}/dataset"
export MODEL_DIR="${WORK_DIR}/models"
export LOG_DIR="${WORK_DIR}/logs"

# 加载必要的模块 (根据集群实际模块名调整)

module load python/3.10 cuda/12.2 cudnn/8.9

# 激活虚拟环境

source ${WORK_DIR}/venv/bin/activate

# 2. 参数定义 (可通过 sbatch --export 传入)

TASK_TYPE=${TASK_TYPE:-"train"} # 可选: train, inference, preprocess
BATCH_SIZE=${BATCH_SIZE:-64}
EPOCHS=${EPOCHS:-100}
IMG_SIZE=${IMG_SIZE:-640}

echo "[$(date)] 开始执行任务: ${TASK_TYPE}"
echo "[$(date)] 使用GPU: $(nvidia-smi -L)"

# 3. 任务分支逻辑

case ${TASK_TYPE} in
    "preprocess")
        echo "[$(date)] 启动数据预处理阶段..."
        # 调用预处理脚本：图像清洗、格式转换、元数据对齐
        python ${WORK_DIR}/scripts/preprocess.py \
            --input_dir ${DATA_DIR}/raw \
            --output_dir ${DATA_DIR}/processed \
            --num_workers ${SLURM_CPUS_PER_TASK}
        ;;
    
    "train")
        echo "[$(date)] 启动模型训练阶段..."
        # 调用YOLOv8训练脚本，启用混合精度训练
        python ${WORK_DIR}/scripts/train_yolo.py \
            --data ${DATA_DIR}/processed/data.yaml \
            --epochs ${EPOCHS} \
            --batch ${BATCH_SIZE} \
            --imgsz ${IMG_SIZE} \
            --device 0 \
            --project ${MODEL_DIR} \
            --name yolov8_plankton_v1 \
            --amp True \
            --workers ${SLURM_CPUS_PER_TASK}
        ;;
    
    "inference")
        echo "[$(date)] 启动全量影像推理阶段..."
        # 调用批量推理脚本，处理112亿张影像的分片任务
        python ${WORK_DIR}/scripts/batch_inference.py \
            --model ${MODEL_DIR}/yolov8_plankton_v1/weights/best.pt \
            --source ${DATA_DIR}/raw/batch_${SLURM_ARRAY_TASK_ID} \
            --output ${DATA_DIR}/results/batch_${SLURM_ARRAY_TASK_ID} \
            --conf 0.25 \
            --iou 0.7 \
            --save-txt
        ;;
        
    *)
        echo "错误: 未知的任务类型 ${TASK_TYPE}"
        exit 1
        ;;
esac

echo "[$(date)] 任务执行完毕，退出码: $?"
