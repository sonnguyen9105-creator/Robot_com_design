
#!/bin/bash

# ==========================================

# 用于提交128TB影像的并行推理作业数组

# 适配场景：将128TB数据拆分为多个批次，利用Slurm Array Jobs并行处理

# ==========================================

# 定义批次总数 (例如：128TB数据拆分为1000个批次)

TOTAL_BATCHES=1000

# 提交作业数组

sbatch \
    --array=1-${TOTAL_BATCHES}%50 \
    --export=ALL,TASK_TYPE=inference \
    submit_plankton_workflow.sh

echo "已提交 ${TOTAL_BATCHES} 个并行推理任务，最大并发数限制为50"
